-- Adicionar coluna whatsapp na tabela rsvps se não existir
ALTER TABLE `rsvps` ADD COLUMN `whatsapp` varchar(20) NOT NULL DEFAULT '';

-- Adicionar coluna guestNames na tabela rsvps se não existir
ALTER TABLE `rsvps` ADD COLUMN `guestNames` text;

-- Adicionar coluna willAttend na tabela rsvps se não existir
ALTER TABLE `rsvps` ADD COLUMN `willAttend` int NOT NULL DEFAULT 1;

-- Adicionar coluna whatsapp na tabela messages se não existir
ALTER TABLE `messages` ADD COLUMN `whatsapp` varchar(20) NOT NULL DEFAULT '';

-- Atualizar o default de isPublic para 0 (privado por padrão)
ALTER TABLE `messages` MODIFY COLUMN `isPublic` int NOT NULL DEFAULT 0;
