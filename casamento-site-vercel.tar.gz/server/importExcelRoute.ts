import { Express, Request, Response } from "express";
import multer from "multer";
import { importExcelFile } from "./importExcel";

const upload = multer({ storage: multer.memoryStorage() });

export function registerImportExcelRoute(app: Express) {
  app.post("/api/import-excel", upload.single("file"), async (req: Request, res: Response) => {
    try {
      if (!req.file) {
        return res.status(400).json({
          success: false,
          message: "Nenhum arquivo foi enviado",
          stats: {
            guestsImported: 0,
            attendantsImported: 0,
            vendorsImported: 0,
            giftsImported: 0,
            eventsImported: 0,
            expensesImported: 0,
            errors: ["Nenhum arquivo foi enviado"],
          },
        });
      }

      const result = await importExcelFile(req.file.buffer);
      return res.json(result);
    } catch (error) {
      console.error("Error importing Excel:", error);
      return res.status(500).json({
        success: false,
        message: "Erro ao importar arquivo Excel",
        stats: {
          guestsImported: 0,
          attendantsImported: 0,
          vendorsImported: 0,
          giftsImported: 0,
          eventsImported: 0,
          expensesImported: 0,
          errors: [String(error)],
        },
      });
    }
  });
}
