import { describe, expect, it, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// Mock context for testing
function createMockContext(): TrpcContext {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("Wedding Router", () => {
  describe("wedding.createRSVP", () => {
    it("should create an RSVP with valid data", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.wedding.createRSVP({
        guestName: "João Silva",
        whatsapp: "(11) 99999-9999",
        willAttend: true,
        numGuests: 2,
        guestNames: ["Maria Silva", "Pedro Silva"],
      });

      expect(result).toEqual({ success: true });
    });

    it("should fail with empty guest name", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.wedding.createRSVP({
          guestName: "",
          whatsapp: "(11) 99999-9999",
          willAttend: true,
          numGuests: 1,
        });
        expect.fail("Should have thrown an error");
      } catch (error: any) {
        expect(error.message).toContain("Nome completo é obrigatório");
      }
    });

    it("should fail with empty whatsapp", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.wedding.createRSVP({
          guestName: "Maria Santos",
          whatsapp: "",
          willAttend: true,
          numGuests: 1,
        });
        expect.fail("Should have thrown an error");
      } catch (error: any) {
        expect(error.message).toContain("WhatsApp é obrigatório");
      }
    });

    it("should accept RSVP with willAttend false", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.wedding.createRSVP({
        guestName: "Ana Costa",
        whatsapp: "(11) 88888-8888",
        willAttend: false,
        numGuests: 0,
      });

      expect(result).toEqual({ success: true });
    });
  });

  describe("wedding.createMessage", () => {
    it("should create a message with valid data", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.wedding.createMessage({
        guestName: "Pedro Costa",
        whatsapp: "(11) 77777-7777",
        content: "Que Deus abençoe este casamento!",
      });

      expect(result).toEqual({ success: true });
    });

    it("should fail with empty guest name", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.wedding.createMessage({
          guestName: "",
          whatsapp: "(11) 77777-7777",
          content: "Mensagem de teste",
        });
        expect.fail("Should have thrown an error");
      } catch (error: any) {
        expect(error.message).toContain("Nome completo é obrigatório");
      }
    });

    it("should fail with empty whatsapp", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.wedding.createMessage({
          guestName: "Ana Silva",
          whatsapp: "",
          content: "Mensagem de teste",
        });
        expect.fail("Should have thrown an error");
      } catch (error: any) {
        expect(error.message).toContain("WhatsApp é obrigatório");
      }
    });

    it("should fail with empty message content", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.wedding.createMessage({
          guestName: "Ana Silva",
          whatsapp: "(11) 77777-7777",
          content: "",
        });
        expect.fail("Should have thrown an error");
      } catch (error: any) {
        expect(error.message).toContain("Mensagem é obrigatória");
      }
    });
  });

  describe("wedding.getMessages", () => {
    it("should return messages array", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.wedding.getMessages();

      expect(Array.isArray(result)).toBe(true);
    });

    it("should return messages in correct order", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.wedding.getMessages();

      // Messages should be returned in descending order by creation date
      if (result.length > 1) {
        for (let i = 0; i < result.length - 1; i++) {
          const current = new Date(result[i].createdAt).getTime();
          const next = new Date(result[i + 1].createdAt).getTime();
          expect(current).toBeGreaterThanOrEqual(next);
        }
      }
      expect(Array.isArray(result)).toBe(true);
    });
  });
});
