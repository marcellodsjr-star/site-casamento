import { eq, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, rsvps, messages, weddingGuests, weddingAttendants, weddingVendors, weddingGifts, weddingEvents, weddingExpenses, weddingInfo } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function createRSVP(data: {
  guestName: string;
  whatsapp: string;
  willAttend: boolean;
  numGuests: number;
  guestNames?: string[];
}) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const rsvpResult = await db.insert(rsvps).values({
    guestName: data.guestName,
    whatsapp: data.whatsapp,
    willAttend: data.willAttend ? 1 : 0,
    numGuests: data.numGuests,
    guestNames: data.guestNames ? JSON.stringify(data.guestNames) : null,
  });

  return rsvpResult;
}

export async function createMessage(data: {
  guestName: string;
  whatsapp: string;
  content: string;
}) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const messageResult = await db.insert(messages).values({
    guestName: data.guestName,
    whatsapp: data.whatsapp,
    content: data.content,
    isPublic: 0, // Always private by default
  });

  return messageResult;
}

export async function getAllMessages() {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const result = await db
    .select()
    .from(messages)
    .orderBy(desc(messages.createdAt));

  return result;
}

export async function getPublicMessages() {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const result = await db
    .select()
    .from(messages)
    .where(eq(messages.isPublic, 1))
    .orderBy(desc(messages.createdAt));

  return result;
}

export async function getAllRSVPs() {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const result = await db
    .select()
    .from(rsvps)
    .orderBy(desc(rsvps.createdAt));

  return result;
}


// ========== WEDDING GUESTS ==========
export async function getAllWeddingGuests() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.select().from(weddingGuests).orderBy(desc(weddingGuests.createdAt));
}

export async function createWeddingGuest(data: {
  name: string;
  side?: string;
  status?: string;
  isPending?: number;
  numGuests?: number;
  phone?: string;
  email?: string;
  notes?: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.insert(weddingGuests).values(data);
}

export async function updateWeddingGuest(id: number, data: Partial<typeof weddingGuests.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.update(weddingGuests).set(data).where(eq(weddingGuests.id, id));
}

export async function deleteWeddingGuest(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.delete(weddingGuests).where(eq(weddingGuests.id, id));
}

// ========== WEDDING ATTENDANTS ==========
export async function getAllWeddingAttendants() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.select().from(weddingAttendants).orderBy(desc(weddingAttendants.createdAt));
}

export async function createWeddingAttendant(data: {
  name: string;
  role?: string;
  side?: string;
  phone?: string;
  email?: string;
  notes?: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.insert(weddingAttendants).values(data);
}

export async function updateWeddingAttendant(id: number, data: Partial<typeof weddingAttendants.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.update(weddingAttendants).set(data).where(eq(weddingAttendants.id, id));
}

export async function deleteWeddingAttendant(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.delete(weddingAttendants).where(eq(weddingAttendants.id, id));
}

// ========== WEDDING VENDORS ==========
export async function getAllWeddingVendors() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.select().from(weddingVendors).orderBy(desc(weddingVendors.createdAt));
}

export async function createWeddingVendor(data: {
  type: string;
  name: string;
  phone?: string;
  email?: string;
  value?: string;
  notes?: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.insert(weddingVendors).values(data);
}

export async function updateWeddingVendor(id: number, data: Partial<typeof weddingVendors.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.update(weddingVendors).set(data).where(eq(weddingVendors.id, id));
}

export async function deleteWeddingVendor(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.delete(weddingVendors).where(eq(weddingVendors.id, id));
}

// ========== WEDDING GIFTS ==========
export async function getAllWeddingGifts() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.select().from(weddingGifts).orderBy(desc(weddingGifts.createdAt));
}

export async function createWeddingGift(data: {
  name: string;
  category?: string;
  description?: string;
  value?: string;
  status?: string;
  reservedBy?: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.insert(weddingGifts).values(data);
}

export async function updateWeddingGift(id: number, data: Partial<typeof weddingGifts.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.update(weddingGifts).set(data).where(eq(weddingGifts.id, id));
}

export async function deleteWeddingGift(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.delete(weddingGifts).where(eq(weddingGifts.id, id));
}

// ========== WEDDING EVENTS ==========
export async function getAllWeddingEvents() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.select().from(weddingEvents).orderBy(desc(weddingEvents.createdAt));
}

export async function createWeddingEvent(data: {
  name: string;
  type?: string;
  location?: string;
  startTime?: string;
  endTime?: string;
  description?: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.insert(weddingEvents).values(data);
}

export async function updateWeddingEvent(id: number, data: Partial<typeof weddingEvents.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.update(weddingEvents).set(data).where(eq(weddingEvents.id, id));
}

export async function deleteWeddingEvent(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.delete(weddingEvents).where(eq(weddingEvents.id, id));
}

// ========== WEDDING EXPENSES ==========
export async function getAllWeddingExpenses() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.select().from(weddingExpenses).orderBy(desc(weddingExpenses.createdAt));
}

export async function createWeddingExpense(data: {
  category: string;
  description?: string;
  value: string;
  status?: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.insert(weddingExpenses).values(data);
}

export async function updateWeddingExpense(id: number, data: Partial<typeof weddingExpenses.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.update(weddingExpenses).set(data).where(eq(weddingExpenses.id, id));
}

export async function deleteWeddingExpense(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.delete(weddingExpenses).where(eq(weddingExpenses.id, id));
}

// ========== WEDDING INFO ==========
export async function getWeddingInfo() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.select().from(weddingInfo).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function createWeddingInfo(data: {
  brideFullName?: string;
  groomFullName?: string;
  weddingDate?: string;
  weddingLocation?: string;
  totalBudget?: string;
  totalGuests?: number;
  totalAttendants?: number;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.insert(weddingInfo).values(data);
}

export async function updateWeddingInfo(id: number, data: Partial<typeof weddingInfo.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.update(weddingInfo).set(data).where(eq(weddingInfo.id, id));
}
