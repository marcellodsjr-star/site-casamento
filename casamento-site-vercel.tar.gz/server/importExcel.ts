import * as XLSX from 'xlsx';
import { createWeddingGuest, createWeddingAttendant, createWeddingVendor, createWeddingGift, createWeddingEvent, createWeddingExpense } from './db';

interface ImportResult {
  success: boolean;
  message: string;
  stats: {
    guestsImported: number;
    attendantsImported: number;
    vendorsImported: number;
    giftsImported: number;
    eventsImported: number;
    expensesImported: number;
    errors: string[];
  };
}

export async function importExcelFile(buffer: Buffer): Promise<ImportResult> {
  const stats = {
    guestsImported: 0,
    attendantsImported: 0,
    vendorsImported: 0,
    giftsImported: 0,
    eventsImported: 0,
    expensesImported: 0,
    errors: [] as string[],
  };

  try {
    // Ler o arquivo Excel
    const workbook = XLSX.read(buffer, { cellFormula: false });
    
    // Processar cada aba
    for (const sheetName of workbook.SheetNames) {
      const worksheet = workbook.Sheets[sheetName];
      const data = XLSX.utils.sheet_to_json(worksheet) as Record<string, unknown>[];

      console.log(`Processando aba: ${sheetName}`);
      console.log(`Dados encontrados: ${data.length}`);

      // Mapear dados baseado no nome da aba
      if (sheetName.toLowerCase().includes('convidado')) {
        // Importar convidados
        for (const row of data) {
          try {
            if (row.Nome || row['Nome do convidado']) {
              const name = (row.Nome || row['Nome do convidado']) as string;
              const side = (row.Lado || row['Lado do casal'] || 'Noiva') as string;
              const status = (row.Status || 'Pendente') as string;
              const numGuests = parseInt(String(row['Acompanhantes'] || '0')) || 0;
              
              await createWeddingGuest({
                name: String(name).trim(),
                side: String(side).trim(),
                status: String(status).trim(),
                numGuests,
                notes: String(row.Observações || row.Notas || ''),
                isPending: String(side).toLowerCase().includes('talvez') || String(status).toLowerCase().includes('pendente') ? 1 : 0,
              });
              stats.guestsImported++;
            }
          } catch (error) {
            stats.errors.push(`Erro ao importar convidado: ${error}`);
          }
        }
      } else if (sheetName.toLowerCase().includes('padrinho') || sheetName.toLowerCase().includes('dama')) {
        // Importar padrinhos
        for (const row of data) {
          try {
            if (row.Nome || row['Nome do padrinho']) {
              const name = (row.Nome || row['Nome do padrinho']) as string;
              const role = (row.Função || row['Função/Papel'] || 'Padrinho') as string;
              const side = (row.Lado || 'Noiva') as string;
              
              await createWeddingAttendant({
                name: String(name).trim(),
                role: String(role).trim(),
                side: String(side).trim(),
                phone: String(row.Contato || row.Telefone || ''),
              });
              stats.attendantsImported++;
            }
          } catch (error) {
            stats.errors.push(`Erro ao importar padrinho: ${error}`);
          }
        }
      } else if (sheetName.toLowerCase().includes('fornecedor') || sheetName.toLowerCase().includes('vendor')) {
        // Importar fornecedores
        for (const row of data) {
          try {
            if (row.Nome || row['Nome do fornecedor']) {
              const name = (row.Nome || row['Nome do fornecedor']) as string;
              const type = (row.Tipo || row['Tipo de serviço'] || 'Outros') as string;
              const phone = (row.Contato || row.Telefone || '') as string;
              const value = String(parseFloat(String(row.Valor || row.Preço || '0').replace(/[^\d.]/g, '')) || 0);
              
              await createWeddingVendor({
                name: String(name).trim(),
                type: String(type).trim(),
                phone: String(phone).trim(),
                value,
                notes: String(row.Status || 'Pendente'),
              });
              stats.vendorsImported++;
            }
          } catch (error) {
            stats.errors.push(`Erro ao importar fornecedor: ${error}`);
          }
        }
      } else if (sheetName.toLowerCase().includes('presente') || sheetName.toLowerCase().includes('gift')) {
        // Importar presentes
        for (const row of data) {
          try {
            if (row.Nome || row['Nome do presente']) {
              const name = (row.Nome || row['Nome do presente']) as string;
              const category = (row.Categoria || 'Geral') as string;
              const value = String(parseFloat(String(row.Valor || row.Preço || '0').replace(/[^\d.]/g, '')) || 0);
              
              await createWeddingGift({
                name: String(name).trim(),
                category: String(category).trim(),
                value,
                status: String(row.Status || 'Disponível'),
              });
              stats.giftsImported++;
            }
          } catch (error) {
            stats.errors.push(`Erro ao importar presente: ${error}`);
          }
        }
      } else if (sheetName.toLowerCase().includes('evento') || sheetName.toLowerCase().includes('event') || sheetName.toLowerCase().includes('roteiro')) {
        // Importar eventos
        for (const row of data) {
          try {
            if (row.Nome || row['Nome do evento']) {
              const name = (row.Nome || row['Nome do evento']) as string;
              const startTime = (row.Horário || row.Hora || '') as string;
              const location = (row.Local || row.Localização || '') as string;
              const description = (row.Descrição || row.Detalhes || '') as string;
              
              await createWeddingEvent({
                name: String(name).trim(),
                startTime: String(startTime).trim(),
                location: String(location).trim(),
                description: String(description).trim(),
              });
              stats.eventsImported++;
            }
          } catch (error) {
            stats.errors.push(`Erro ao importar evento: ${error}`);
          }
        }
      } else if (sheetName.toLowerCase().includes('despesa') || sheetName.toLowerCase().includes('gasto') || sheetName.toLowerCase().includes('expense')) {
        // Importar despesas
        for (const row of data) {
          try {
            if (row.Descrição || row['Descrição da despesa']) {
              const description = (row.Descrição || row['Descrição da despesa']) as string;
              const category = (row.Categoria || 'Outros') as string;
              const value = String(parseFloat(String(row.Valor || row.Preço || '0').replace(/[^\d.]/g, '')) || 0);
              const status = (row.Status || 'Planejado') as string;
              
              await createWeddingExpense({
                description: String(description).trim(),
                category: String(category).trim(),
                value,
                status: String(status).trim(),
              });
              stats.expensesImported++;
            }
          } catch (error) {
            stats.errors.push(`Erro ao importar despesa: ${error}`);
          }
        }
      }
    }

    return {
      success: true,
      message: `Importação concluída com sucesso!`,
      stats,
    };
  } catch (error) {
    return {
      success: false,
      message: `Erro ao processar arquivo: ${error}`,
      stats,
    };
  }
}
