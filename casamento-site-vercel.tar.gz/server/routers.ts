import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { createRSVP, createMessage, getAllMessages, getAllRSVPs, getAllWeddingGuests, createWeddingGuest, updateWeddingGuest, deleteWeddingGuest, getAllWeddingAttendants, createWeddingAttendant, updateWeddingAttendant, deleteWeddingAttendant, getAllWeddingVendors, createWeddingVendor, updateWeddingVendor, deleteWeddingVendor, getAllWeddingGifts, createWeddingGift, updateWeddingGift, deleteWeddingGift, getAllWeddingEvents, createWeddingEvent, updateWeddingEvent, deleteWeddingEvent, getAllWeddingExpenses, createWeddingExpense, updateWeddingExpense, deleteWeddingExpense, getWeddingInfo, createWeddingInfo, updateWeddingInfo } from "./db";

import { z } from "zod";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  rsvp: router({
    getAll: publicProcedure.query(async () => {
      try {
        const rsvps = await getAllRSVPs();
        return rsvps;
      } catch (error) {
        console.error("Error getting RSVPs:", error);
        return [];
      }
    }),
  }),

  messages: router({
    getAll: publicProcedure.query(async () => {
      try {
        const messages = await getAllMessages();
        return messages;
      } catch (error) {
        console.error("Error getting messages:", error);
        return [];
      }
    }),
  }),

  wedding: router({
    createRSVP: publicProcedure
      .input(
        z.object({
          guestName: z.string().min(1, "Nome completo é obrigatório"),
          whatsapp: z.string().min(1, "WhatsApp é obrigatório"),
          willAttend: z.boolean(),
          numGuests: z.number().int().min(0, "Número de acompanhantes deve ser 0 ou maior"),
          guestNames: z.array(z.string()).optional(),
        })
      )
      .mutation(async ({ input }) => {
        try {
          await createRSVP({
            guestName: input.guestName,
            whatsapp: input.whatsapp,
            willAttend: input.willAttend,
            numGuests: input.numGuests,
            guestNames: input.guestNames,
          });
          return { success: true };
        } catch (error) {
          console.error("Error creating RSVP:", error);
          throw new Error("Erro ao confirmar presença");
        }
      }),

    createMessage: publicProcedure
      .input(
        z.object({
          guestName: z.string().min(1, "Nome completo é obrigatório"),
          whatsapp: z.string().min(1, "WhatsApp é obrigatório"),
          content: z.string().min(1, "Mensagem é obrigatória"),
        })
      )
      .mutation(async ({ input }) => {
        try {
          await createMessage({
            guestName: input.guestName,
            whatsapp: input.whatsapp,
            content: input.content,
          });
          return { success: true };
        } catch (error) {
          console.error("Error creating message:", error);
          throw new Error("Erro ao enviar mensagem");
        }
      }),

    getMessages: publicProcedure.query(async () => {
      try {
        const messages = await getAllMessages();
        return messages;
      } catch (error) {
        console.error("Error getting messages:", error);
        return [];
      }
    }),

    getAllRSVPs: publicProcedure.query(async () => {
      try {
        const rsvps = await getAllRSVPs();
        return rsvps;
      } catch (error) {
        console.error("Error getting RSVPs:", error);
        return [];
      }
    }),
  }),

  weddingPlanning: router({
    guests: router({
      getAll: publicProcedure.query(async () => {
        try {
          return await getAllWeddingGuests();
        } catch (error) {
          console.error("Error getting guests:", error);
          return [];
        }
      }),
      create: publicProcedure
        .input(
          z.object({
            name: z.string().min(1),
            side: z.string().optional(),
            status: z.string().optional(),
            isPending: z.number().optional(),
            numGuests: z.number().optional(),
            phone: z.string().optional(),
            email: z.string().optional(),
            notes: z.string().optional(),
          })
        )
        .mutation(async ({ input }) => {
          try {
            return await createWeddingGuest(input);
          } catch (error) {
            console.error("Error creating guest:", error);
            throw new Error("Erro ao criar convidado");
          }
        }),
      update: publicProcedure
        .input(
          z.object({
            id: z.number(),
            data: z.object({
              name: z.string().optional(),
              side: z.string().optional(),
              status: z.string().optional(),
              isPending: z.number().optional(),
              numGuests: z.number().optional(),
              phone: z.string().optional(),
              email: z.string().optional(),
              notes: z.string().optional(),
            }),
          })
        )
        .mutation(async ({ input }) => {
          try {
            return await updateWeddingGuest(input.id, input.data);
          } catch (error) {
            console.error("Error updating guest:", error);
            throw new Error("Erro ao atualizar convidado");
          }
        }),
      delete: publicProcedure
        .input(z.object({ id: z.number() }))
        .mutation(async ({ input }) => {
          try {
            return await deleteWeddingGuest(input.id);
          } catch (error) {
            console.error("Error deleting guest:", error);
            throw new Error("Erro ao deletar convidado");
          }
        }),
    }),

    attendants: router({
      getAll: publicProcedure.query(async () => {
        try {
          return await getAllWeddingAttendants();
        } catch (error) {
          console.error("Error getting attendants:", error);
          return [];
        }
      }),
      create: publicProcedure
        .input(
          z.object({
            name: z.string().min(1),
            role: z.string().optional(),
            side: z.string().optional(),
            phone: z.string().optional(),
            email: z.string().optional(),
            notes: z.string().optional(),
          })
        )
        .mutation(async ({ input }) => {
          try {
            return await createWeddingAttendant(input);
          } catch (error) {
            console.error("Error creating attendant:", error);
            throw new Error("Erro ao criar padrinho/madrinha");
          }
        }),
      update: publicProcedure
        .input(
          z.object({
            id: z.number(),
            data: z.object({
              name: z.string().optional(),
              role: z.string().optional(),
              side: z.string().optional(),
              phone: z.string().optional(),
              email: z.string().optional(),
              notes: z.string().optional(),
            }),
          })
        )
        .mutation(async ({ input }) => {
          try {
            return await updateWeddingAttendant(input.id, input.data);
          } catch (error) {
            console.error("Error updating attendant:", error);
            throw new Error("Erro ao atualizar padrinho/madrinha");
          }
        }),
      delete: publicProcedure
        .input(z.object({ id: z.number() }))
        .mutation(async ({ input }) => {
          try {
            return await deleteWeddingAttendant(input.id);
          } catch (error) {
            console.error("Error deleting attendant:", error);
            throw new Error("Erro ao deletar padrinho/madrinha");
          }
        }),
    }),

    vendors: router({
      getAll: publicProcedure.query(async () => {
        try {
          return await getAllWeddingVendors();
        } catch (error) {
          console.error("Error getting vendors:", error);
          return [];
        }
      }),
      create: publicProcedure
        .input(
          z.object({
            type: z.string().min(1),
            name: z.string().min(1),
            phone: z.string().optional(),
            email: z.string().optional(),
            value: z.string().optional(),
            notes: z.string().optional(),
          })
        )
        .mutation(async ({ input }) => {
          try {
            return await createWeddingVendor(input);
          } catch (error) {
            console.error("Error creating vendor:", error);
            throw new Error("Erro ao criar fornecedor");
          }
        }),
      update: publicProcedure
        .input(
          z.object({
            id: z.number(),
            data: z.object({
              type: z.string().optional(),
              name: z.string().optional(),
              phone: z.string().optional(),
              email: z.string().optional(),
              value: z.string().optional(),
              notes: z.string().optional(),
            }),
          })
        )
        .mutation(async ({ input }) => {
          try {
            return await updateWeddingVendor(input.id, input.data);
          } catch (error) {
            console.error("Error updating vendor:", error);
            throw new Error("Erro ao atualizar fornecedor");
          }
        }),
      delete: publicProcedure
        .input(z.object({ id: z.number() }))
        .mutation(async ({ input }) => {
          try {
            return await deleteWeddingVendor(input.id);
          } catch (error) {
            console.error("Error deleting vendor:", error);
            throw new Error("Erro ao deletar fornecedor");
          }
        }),
    }),

    gifts: router({
      getAll: publicProcedure.query(async () => {
        try {
          return await getAllWeddingGifts();
        } catch (error) {
          console.error("Error getting gifts:", error);
          return [];
        }
      }),
      create: publicProcedure
        .input(
          z.object({
            name: z.string().min(1),
            category: z.string().optional(),
            description: z.string().optional(),
            value: z.string().optional(),
            status: z.string().optional(),
            reservedBy: z.string().optional(),
          })
        )
        .mutation(async ({ input }) => {
          try {
            return await createWeddingGift(input);
          } catch (error) {
            console.error("Error creating gift:", error);
            throw new Error("Erro ao criar presente");
          }
        }),
      update: publicProcedure
        .input(
          z.object({
            id: z.number(),
            data: z.object({
              name: z.string().optional(),
              category: z.string().optional(),
              description: z.string().optional(),
              value: z.string().optional(),
              status: z.string().optional(),
              reservedBy: z.string().optional(),
            }),
          })
        )
        .mutation(async ({ input }) => {
          try {
            return await updateWeddingGift(input.id, input.data);
          } catch (error) {
            console.error("Error updating gift:", error);
            throw new Error("Erro ao atualizar presente");
          }
        }),
      delete: publicProcedure
        .input(z.object({ id: z.number() }))
        .mutation(async ({ input }) => {
          try {
            return await deleteWeddingGift(input.id);
          } catch (error) {
            console.error("Error deleting gift:", error);
            throw new Error("Erro ao deletar presente");
          }
        }),
    }),

    events: router({
      getAll: publicProcedure.query(async () => {
        try {
          return await getAllWeddingEvents();
        } catch (error) {
          console.error("Error getting events:", error);
          return [];
        }
      }),
      create: publicProcedure
        .input(
          z.object({
            name: z.string().min(1),
            type: z.string().optional(),
            location: z.string().optional(),
            startTime: z.string().optional(),
            endTime: z.string().optional(),
            description: z.string().optional(),
          })
        )
        .mutation(async ({ input }) => {
          try {
            return await createWeddingEvent(input);
          } catch (error) {
            console.error("Error creating event:", error);
            throw new Error("Erro ao criar evento");
          }
        }),
      update: publicProcedure
        .input(
          z.object({
            id: z.number(),
            data: z.object({
              name: z.string().optional(),
              type: z.string().optional(),
              location: z.string().optional(),
              startTime: z.string().optional(),
              endTime: z.string().optional(),
              description: z.string().optional(),
            }),
          })
        )
        .mutation(async ({ input }) => {
          try {
            return await updateWeddingEvent(input.id, input.data);
          } catch (error) {
            console.error("Error updating event:", error);
            throw new Error("Erro ao atualizar evento");
          }
        }),
      delete: publicProcedure
        .input(z.object({ id: z.number() }))
        .mutation(async ({ input }) => {
          try {
            return await deleteWeddingEvent(input.id);
          } catch (error) {
            console.error("Error deleting event:", error);
            throw new Error("Erro ao deletar evento");
          }
        }),
    }),

    expenses: router({
      getAll: publicProcedure.query(async () => {
        try {
          return await getAllWeddingExpenses();
        } catch (error) {
          console.error("Error getting expenses:", error);
          return [];
        }
      }),
      create: publicProcedure
        .input(
          z.object({
            category: z.string().min(1),
            description: z.string().optional(),
            value: z.string().min(1),
            status: z.string().optional(),
          })
        )
        .mutation(async ({ input }) => {
          try {
            return await createWeddingExpense(input);
          } catch (error) {
            console.error("Error creating expense:", error);
            throw new Error("Erro ao criar despesa");
          }
        }),
      update: publicProcedure
        .input(
          z.object({
            id: z.number(),
            data: z.object({
              category: z.string().optional(),
              description: z.string().optional(),
              value: z.string().optional(),
              status: z.string().optional(),
            }),
          })
        )
        .mutation(async ({ input }) => {
          try {
            return await updateWeddingExpense(input.id, input.data);
          } catch (error) {
            console.error("Error updating expense:", error);
            throw new Error("Erro ao atualizar despesa");
          }
        }),
      delete: publicProcedure
        .input(z.object({ id: z.number() }))
        .mutation(async ({ input }) => {
          try {
            return await deleteWeddingExpense(input.id);
          } catch (error) {
            console.error("Error deleting expense:", error);
            throw new Error("Erro ao deletar despesa");
          }
        }),
    }),

    info: router({
      get: publicProcedure.query(async () => {
        try {
          return await getWeddingInfo();
        } catch (error) {
          console.error("Error getting wedding info:", error);
          return null;
        }
      }),
      create: publicProcedure
        .input(
          z.object({
            brideFullName: z.string().optional(),
            groomFullName: z.string().optional(),
            weddingDate: z.string().optional(),
            weddingLocation: z.string().optional(),
            totalBudget: z.string().optional(),
            totalGuests: z.number().optional(),
            totalAttendants: z.number().optional(),
          })
        )
        .mutation(async ({ input }) => {
          try {
            return await createWeddingInfo(input);
          } catch (error) {
            console.error("Error creating wedding info:", error);
            throw new Error("Erro ao criar informações do casamento");
          }
        }),
      update: publicProcedure
        .input(
          z.object({
            id: z.number(),
            data: z.object({
              brideFullName: z.string().optional(),
              groomFullName: z.string().optional(),
              weddingDate: z.string().optional(),
              weddingLocation: z.string().optional(),
              totalBudget: z.string().optional(),
              totalGuests: z.number().optional(),
              totalAttendants: z.number().optional(),
            }),
          })
        )
        .mutation(async ({ input }) => {
          try {
            return await updateWeddingInfo(input.id, input.data);
          } catch (error) {
            console.error("Error updating wedding info:", error);
            throw new Error("Erro ao atualizar informações do casamento");
          }
        }),
    }),
  }),
});

export type AppRouter = typeof appRouter;
