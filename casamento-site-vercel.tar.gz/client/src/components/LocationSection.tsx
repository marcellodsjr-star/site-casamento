import { motion } from "framer-motion";
import { MapPin, Clock, Calendar } from "lucide-react";

declare global {
  namespace JSX {
    interface IframeHTMLAttributes<T> {
      allowFullScreen?: boolean;
    }
  }
}

export default function LocationSection() {
  const locationUrl = "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3653.034730285132!2d-46.358016923879546!3d-23.71045376708803!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94ce72af0357ccbb%3A0x5a733c17312d73bb!2sEspa%C3%A7o%20de%20Eventos%20Ch%C3%A1cara%20Recanto%20Vale%20das%20%C3%81guas!5e0!3m2!1spt-BR!2sbr!4v1777993779955!5m2!1spt-BR!2sbr";

  // Google Calendar URL
  const googleCalendarUrl = "https://calendar.google.com/calendar/render?action=TEMPLATE&text=Casamento%20Thalita%20%26%20Marcelo&dates=20261220T130000/20261220T230000&location=Estrada%20do%20Soma%2C%20243%2C%20Ouro%20Fino%20Paulista%2C%20Ribeir%C3%A3o%20Pires%20-%20SP&details=Cerim%C3%B4nia%20e%20Recep%C3%A7%C3%A3o%20do%20casamento%20de%20Thalita%20e%20Marcelo";

  // ICS Calendar (Apple/Outlook/Android)
  const icsContent = `BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Casamento Thalita Marcelo//EN
CALSCALE:GREGORIAN
METHOD:PUBLISH
BEGIN:VEVENT
UID:casamento-thalita-marcelo-2026@example.com
DTSTAMP:20260101T000000Z
DTSTART:20261220T130000
DTEND:20261220T230000
SUMMARY:Casamento Thalita & Marcelo
DESCRIPTION:Cerimônia e Recepção do casamento de Thalita e Marcelo
LOCATION:Estrada do Soma, 243, Ouro Fino Paulista, Ribeirão Pires - SP, 09445-550
STATUS:CONFIRMED
SEQUENCE:0
END:VEVENT
END:VCALENDAR`;

  const icsUrl = `data:text/calendar;charset=utf-8,${encodeURIComponent(icsContent)}`;

  return (
    <section id="location" className="section-location py-20 px-4 border-b border-gray-200">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, translateY: 30 }}
          whileInView={{ opacity: 1, translateY: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true, margin: "-100px" }}
        >
          <p className="serif-font text-sm uppercase tracking-widest text-gray-500 mb-6 text-center">
            Cerimônia & Recepção
          </p>
          <h2 className="serif-font text-4xl md:text-5xl mb-12 text-center text-gray-900 dark:text-foreground">
            Horário e Local
          </h2>

          {/* Informações */}
          <div className="bg-card border border-border rounded-lg p-8 mb-12 shadow-sm dark:shadow-md">
            <h3 className="serif-font text-2xl mb-6 text-gray-900 dark:text-foreground">Recanto Vale das Águas</h3>
            
            <div className="space-y-4 mb-6">
              <div className="flex items-start gap-4">
                <MapPin className="w-5 h-5 text-gray-600 dark:text-foreground/60 mt-1 flex-shrink-0" />
                <div>
                  <p className="serif-font text-gray-700 dark:text-foreground/80">
                    Estrada do Soma, nº 243
                    <br />
                    Ouro Fino Paulista, Ribeirão Pires — SP
                    <br />
                    CEP 09445-550
                  </p>
                </div>
              </div>
              
              <div className="flex items-start gap-4">
                <Clock className="w-5 h-5 text-gray-600 dark:text-foreground/60 mt-1 flex-shrink-0" />
                <div>
                  <p className="serif-font text-gray-700 dark:text-foreground/80">
                    <strong>Cerimônia e Recepção às 13h</strong>
                    <br />
                    20 de dezembro de 2026
                  </p>
                  <p className="serif-font text-sm text-gray-600 dark:text-foreground/60 mt-2">
                    Chegue com antecedência para aproveitar melhor o dia
                  </p>
                </div>
              </div>
            </div>

            {/* Links - Minimalista */}
            <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center">
              <a
                href="https://maps.app.goo.gl/5o7MUjcDxQ6336mh8"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-block serif-font text-sm uppercase tracking-widest text-gray-900 dark:text-foreground border-b-2 border-gray-900 dark:border-foreground pb-1 hover:text-gray-600 dark:hover:text-foreground/70 hover:border-gray-600 dark:hover:border-foreground/70 transition-colors"
              >
                Abrir no Google Maps
              </a>

              {/* Calendários - Minimalista */}
              <div className="flex gap-3 items-center flex-wrap">
                <span className="text-xs text-gray-500 dark:text-foreground/50 uppercase tracking-widest">Adicionar ao:</span>
                <a
                  href={googleCalendarUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 text-xs text-gray-600 dark:text-foreground/70 hover:text-gray-900 dark:hover:text-foreground transition-colors"
                  title="Google Calendar"
                >
                  <Calendar className="w-4 h-4" />
                  <span>Google</span>
                </a>
                <span className="text-gray-300 dark:text-foreground/20">•</span>
                <a
                  href={icsUrl}
                  download="casamento-thalita-marcelo.ics"
                  className="inline-flex items-center gap-1 text-xs text-gray-600 dark:text-foreground/70 hover:text-gray-900 dark:hover:text-foreground transition-colors"
                  title="Apple Calendar / Outlook / Android"
                >
                  <Calendar className="w-4 h-4" />
                  <span>Apple/Outlook</span>
                </a>
              </div>
            </div>
          </div>

          {/* Mapa */}
          <div className="rounded-2xl overflow-hidden h-96 md:h-[500px] shadow-[0_4px_6px_-1px_rgba(0,0,0,0.1),0_2px_4px_-1px_rgba(0,0,0,0.06)] hover:shadow-[0_20px_25px_-5px_rgba(0,0,0,0.1),0_10px_10px_-5px_rgba(0,0,0,0.04)] transition-all duration-300">
            <iframe
              width="100%"
              height="100%"
              frameBorder="0"
              src={locationUrl}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            ></iframe>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
