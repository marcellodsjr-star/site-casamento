import { useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Heart } from "lucide-react";

interface ThankYouModalProps {
  isOpen: boolean;
  onClose: () => void;
  message?: string;
}

export default function ThankYouModal({
  isOpen,
  onClose,
  message = "Deus abençoe",
}: ThankYouModalProps) {
  useEffect(() => {
    if (isOpen) {
      const timer = setTimeout(() => {
        onClose();
      }, 3000);

      return () => clearTimeout(timer);
    }
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <AnimatePresence mode="wait">
      <motion.div
        key="modal-backdrop"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.3 }}
        className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
        onClick={onClose}
      >
        <motion.div
          key="modal-content"
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.8, opacity: 0 }}
          transition={{ type: "spring", damping: 15, duration: 0.3 }}
          className="bg-white rounded-lg p-8 md:p-12 max-w-md w-full text-center shadow-2xl"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="mb-6">
            <Heart className="w-16 h-16 text-red-400 mx-auto" />
          </div>

          <p className="dancing-script-font text-5xl text-gray-900 mb-4">
            {message}
          </p>

          <p className="serif-font text-gray-600 text-lg">
            Obrigado por celebrar conosco!
          </p>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
