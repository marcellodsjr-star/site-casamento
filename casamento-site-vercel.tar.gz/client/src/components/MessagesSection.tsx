import { useState } from "react";
import { motion } from "framer-motion";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import ThankYouModal from "@/components/ThankYouModal";
import { Loader2 } from "lucide-react";

export default function MessagesSection() {
  const [formData, setFormData] = useState({
    guestName: "",
    whatsapp: "",
    content: "",
  });
  const [showThankYou, setShowThankYou] = useState(false);

  const createMessage = trpc.wedding.createMessage.useMutation({
    onSuccess: () => {
      setShowThankYou(true);
      setFormData({ guestName: "", whatsapp: "", content: "" });
    },
    onError: (error) => {
      console.error("Error:", error);
      alert("Erro ao enviar mensagem. Tente novamente.");
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.guestName.trim()) {
      alert("Por favor, digite seu nome completo");
      return;
    }

    if (!formData.whatsapp.trim()) {
      alert("Por favor, digite seu WhatsApp");
      return;
    }

    if (!formData.content.trim()) {
      alert("Por favor, digite uma mensagem");
      return;
    }

    createMessage.mutate({
      guestName: formData.guestName,
      whatsapp: formData.whatsapp,
      content: formData.content,
    });
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  return (
    <section id="messages" className="section-messages py-20 px-4 border-b border-gray-200 dark:border-white/15 bg-white dark:bg-[#151515]">
      <div className="max-w-2xl mx-auto">
        <motion.div
          initial={{ opacity: 0, translateY: 30 }}
          whileInView={{ opacity: 1, translateY: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true, margin: "-100px" }}
        >
          <p className="serif-font text-sm uppercase tracking-widest text-gray-500 dark:text-gray-400 mb-6 text-center">
            Deixe seus Votos
          </p>
          <h2 className="serif-font text-4xl md:text-5xl mb-12 text-center text-gray-900 dark:text-white">
            Recados & Mensagens
          </h2>

          <ThankYouModal
            isOpen={showThankYou}
            onClose={() => setShowThankYou(false)}
            message="Deus abençoe"
          />

          {/* Form */}
          <form onSubmit={handleSubmit} className="bg-white dark:bg-[#1a1a1a] shadow-[0_4px_6px_-1px_rgba(0,0,0,0.1),0_2px_4px_-1px_rgba(0,0,0,0.06)] hover:shadow-[0_20px_25px_-5px_rgba(0,0,0,0.1),0_10px_10px_-5px_rgba(0,0,0,0.04)] transition-all duration-300 rounded-2xl p-8 space-y-6">
            {/* Nome Completo */}
            <div>
              <label className="serif-font block text-sm font-medium text-gray-700 dark:text-white mb-2">
                Seu Nome Completo *
              </label>
              <Input
                type="text"
                name="guestName"
                value={formData.guestName}
                onChange={handleChange}
                placeholder="Digite seu nome completo"
                className="w-full dark:bg-[#2a2a2a] dark:text-white dark:border-white/15"
                required
              />
            </div>

            {/* WhatsApp */}
            <div>
              <label className="serif-font block text-sm font-medium text-gray-700 dark:text-white mb-2">
                Seu WhatsApp *
              </label>
              <Input
                type="tel"
                name="whatsapp"
                value={formData.whatsapp}
                onChange={handleChange}
                placeholder="(11) 99999-9999"
                className="w-full dark:bg-[#2a2a2a] dark:text-white dark:border-white/15"
                required
              />
            </div>

            {/* Mensagem */}
            <div>
              <label className="serif-font block text-sm font-medium text-gray-700 dark:text-white mb-2">
                Sua Mensagem *
              </label>
              <Textarea
                name="content"
                value={formData.content}
                onChange={handleChange}
                placeholder="Deixe seus votos e bênçãos para os noivos..."
                className="w-full dark:bg-[#2a2a2a] dark:text-white dark:border-white/15"
                rows={5}
                required
              />
              <p className="serif-font text-xs text-gray-500 dark:text-gray-400 mt-2">
                Esta mensagem é privada e será vista apenas pelos noivos.
              </p>
            </div>

            {/* Submit Button */}
            <Button
              type="submit"
              disabled={createMessage.isPending}
              className="w-full serif-font bg-gray-900 dark:bg-white hover:bg-gray-800 dark:hover:bg-gray-200 text-white dark:text-black py-2 rounded-md font-medium transition-colors"
            >
              {createMessage.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Enviando...
                </>
              ) : (
                "Enviar Mensagem"
              )}
            </Button>
          </form>

          {/* Info Box */}
          <div className="mt-8 bg-blue-50 dark:bg-[#1a2a3a] border border-blue-200 dark:border-blue-900/50 rounded-lg p-6 text-center">
            <p className="serif-font text-gray-700 dark:text-white">
              <strong>Suas mensagens são privadas!</strong>
              <br />
              <span className="text-sm text-gray-600 dark:text-gray-300 mt-2 block">
                Apenas Thalita e Marcelo poderão ver seus votos e mensagens.
              </span>
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
