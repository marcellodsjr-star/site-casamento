import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Plus, Trash2, Edit2, X } from "lucide-react";
import GuestsList from "./dashboard/GuestsList";
import AttendantsList from "./dashboard/AttendantsList";
import VendorsList from "./dashboard/VendorsList";
import GiftsList from "./dashboard/GiftsList";
import EventsList from "./dashboard/EventsList";
import ExpensesList from "./dashboard/ExpensesList";
import { ExcelImporter } from "./dashboard/ExcelImporter";

type TabType = "guests" | "attendants" | "vendors" | "gifts" | "events" | "expenses" | "import";

export default function WeddingDashboard() {
  const [activeTab, setActiveTab] = useState<TabType>("guests");

  const tabs: { id: TabType; label: string; icon: string }[] = [
    { id: "import", label: "Importar Excel", icon: "📥" },
    { id: "guests", label: "Convidados", icon: "👥" },
    { id: "attendants", label: "Padrinhos", icon: "💍" },
    { id: "vendors", label: "Fornecedores", icon: "🎯" },
    { id: "gifts", label: "Presentes", icon: "🎁" },
    { id: "events", label: "Roteiro", icon: "📅" },
    { id: "expenses", label: "Financeiro", icon: "💰" },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800 p-4 md:p-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="pinyon-script-font text-5xl md:text-6xl mb-2 text-gray-900 dark:text-white">
          Painel de Gestão
        </h1>
        <p className="text-gray-600 dark:text-gray-300">
          Organize todos os detalhes do seu casamento
        </p>
      </div>

      {/* Tab Navigation */}
      <div className="mb-8 flex flex-wrap gap-2 bg-white dark:bg-slate-800 p-4 rounded-lg shadow-sm border border-gray-200 dark:border-slate-700">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-4 py-2 rounded-lg font-medium transition-all ${
              activeTab === tab.id
                ? "bg-blue-600 text-white shadow-md"
                : "bg-gray-100 dark:bg-slate-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-slate-600"
            }`}
          >
            <span className="mr-2">{tab.icon}</span>
            {tab.label}
          </button>
        ))}
      </div>

      {/* Content Area */}
      <div className="bg-white dark:bg-slate-800 rounded-lg shadow-lg border border-gray-200 dark:border-slate-700 p-6">
        {activeTab === "import" && <ExcelImporter />}
        {activeTab === "guests" && <GuestsList />}
        {activeTab === "attendants" && <AttendantsList />}
        {activeTab === "vendors" && <VendorsList />}
        {activeTab === "gifts" && <GiftsList />}
        {activeTab === "events" && <EventsList />}
        {activeTab === "expenses" && <ExpensesList />}
      </div>
    </div>
  );
}
