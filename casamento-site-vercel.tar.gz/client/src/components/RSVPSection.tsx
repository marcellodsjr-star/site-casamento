import { useState } from "react";
import { motion } from "framer-motion";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import ThankYouModal from "@/components/ThankYouModal";
import { Loader2, Plus, Minus } from "lucide-react";

export default function RSVPSection() {
  const [formData, setFormData] = useState({
    guestName: "",
    whatsapp: "",
    willAttend: true,
    numGuests: 0,
    guestNames: [""],
  });
  const [showThankYou, setShowThankYou] = useState(false);

  const createRSVP = trpc.wedding.createRSVP.useMutation({
    onSuccess: () => {
      setShowThankYou(true);
      setFormData({
        guestName: "",
        whatsapp: "",
        willAttend: true,
        numGuests: 0,
        guestNames: [""],
      });
    },
    onError: (error) => {
      console.error("Error:", error);
      alert("Erro ao confirmar presença. Tente novamente.");
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.guestName.trim()) {
      alert("Por favor, digite seu nome completo");
      return;
    }

    if (!formData.whatsapp.trim()) {
      alert("Por favor, digite seu WhatsApp");
      return;
    }

    const guestNames = formData.willAttend && formData.numGuests > 0 
      ? formData.guestNames.filter(name => name.trim())
      : undefined;

    createRSVP.mutate({
      guestName: formData.guestName,
      whatsapp: formData.whatsapp,
      willAttend: formData.willAttend,
      numGuests: formData.numGuests,
      guestNames: guestNames,
    });
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value, type } = e.target;
    
    if (type === "checkbox") {
      const checked = (e.target as HTMLInputElement).checked;
      setFormData((prev) => ({
        ...prev,
        willAttend: checked,
        numGuests: checked ? prev.numGuests : 0,
        guestNames: checked ? prev.guestNames : [""],
      }));
    } else if (name === "numGuests") {
      const num = parseInt(value) || 0;
      setFormData((prev) => ({
        ...prev,
        numGuests: num,
        guestNames: Array(num).fill(""),
      }));
    } else if (name.startsWith("guestName_")) {
      const index = parseInt(name.split("_")[1]);
      const newGuestNames = [...formData.guestNames];
      newGuestNames[index] = value;
      setFormData((prev) => ({
        ...prev,
        guestNames: newGuestNames,
      }));
    } else {
      setFormData((prev) => ({
        ...prev,
        [name]: value,
      }));
    }
  };

  const incrementGuests = () => {
    if (formData.numGuests < 8) {
      const newNum = formData.numGuests + 1;
      setFormData((prev) => ({
        ...prev,
        numGuests: newNum,
        guestNames: [...prev.guestNames, ""],
      }));
    }
  };

  const decrementGuests = () => {
    if (formData.numGuests > 0) {
      const newNum = formData.numGuests - 1;
      const newGuestNames = formData.guestNames.slice(0, newNum);
      setFormData((prev) => ({
        ...prev,
        numGuests: newNum,
        guestNames: newGuestNames,
      }));
    }
  };

  return (
    <section id="rsvp" className="section-rsvp py-20 px-4 border-b border-gray-200 dark:border-white/15 bg-white dark:bg-[#151515]">
      <div className="max-w-2xl mx-auto">
        <motion.div
          initial={{ opacity: 0, translateY: 30 }}
          whileInView={{ opacity: 1, translateY: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true, margin: "-100px" }}
        >
          <p className="serif-font text-sm uppercase tracking-widest text-gray-500 dark:text-gray-400 mb-6 text-center">
            Confirme sua Presença
          </p>
          <h2 className="serif-font text-4xl md:text-5xl mb-12 text-center text-gray-900 dark:text-white">
            RSVP
          </h2>
          <p className="serif-font text-sm md:text-lg text-gray-700 dark:text-white text-center mb-8 whitespace-nowrap md:whitespace-normal overflow-hidden text-ellipsis">
            Por favor, confirme sua presença até <strong>15 de novembro</strong>
          </p>

          <ThankYouModal
            isOpen={showThankYou}
            onClose={() => setShowThankYou(false)}
            message="Deus abençoe"
          />

          <form onSubmit={handleSubmit} className="bg-white dark:bg-[#1a1a1a] shadow-[0_4px_6px_-1px_rgba(0,0,0,0.1),0_2px_4px_-1px_rgba(0,0,0,0.06)] hover:shadow-[0_20px_25px_-5px_rgba(0,0,0,0.1),0_10px_10px_-5px_rgba(0,0,0,0.04)] transition-all duration-300 rounded-2xl p-8 space-y-6">
            {/* Nome Completo */}
            <div>
              <label className="serif-font block text-sm font-medium text-gray-700 dark:text-white mb-2">
                Nome Completo *
              </label>
              <Input
                type="text"
                name="guestName"
                value={formData.guestName}
                onChange={handleChange}
                placeholder="Digite seu nome completo"
                className="w-full dark:bg-[#2a2a2a] dark:text-white dark:border-white/15"
                required
              />
            </div>

            {/* WhatsApp */}
            <div>
              <label className="serif-font block text-sm font-medium text-gray-700 dark:text-white mb-2">
                WhatsApp *
              </label>
              <Input
                type="tel"
                name="whatsapp"
                value={formData.whatsapp}
                onChange={handleChange}
                placeholder="(11) 99999-9999"
                className="w-full dark:bg-[#2a2a2a] dark:text-white dark:border-white/15"
                required
              />
            </div>

            {/* Confirmação de Presença */}
            <div>
              <label className="serif-font block text-sm font-medium text-gray-700 dark:text-white mb-3">
                Você irá compareccer? *
              </label>
              <div className="flex gap-4">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="radio"
                    name="willAttend"
                    value="true"
                    checked={formData.willAttend === true}
                    onChange={() => setFormData(prev => ({ ...prev, willAttend: true }))}
                    className="w-4 h-4"
                  />
                  <span className="serif-font text-gray-700 dark:text-white">Sim, vou comparecer</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="radio"
                    name="willAttend"
                    value="false"
                    checked={formData.willAttend === false}
                    onChange={() => setFormData(prev => ({ ...prev, willAttend: false, numGuests: 0 }))}
                    className="w-4 h-4"
                  />
                  <span className="serif-font text-gray-700 dark:text-white">Não vou poder comparecer</span>
                </label>
              </div>
            </div>

            {/* Acompanhantes - Modern Button Style */}
            {formData.willAttend && (
              <>
                <div>
                  <label className="serif-font block text-sm font-medium text-gray-700 dark:text-white mb-4">
                    Quantas pessoas virão com você? *
                  </label>
                  <div className="flex items-center justify-center gap-4">
                    <button
                      type="button"
                      onClick={decrementGuests}
                      disabled={formData.numGuests === 0}
                      className="flex items-center justify-center w-12 h-12 rounded-full border-2 border-gray-300 dark:border-white/30 hover:border-gray-900 dark:hover:border-white hover:bg-gray-50 dark:hover:bg-white/10 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <Minus className="w-5 h-5 text-gray-700 dark:text-white" />
                    </button>
                    
                    <div className="bg-gradient-to-r from-gray-50 to-gray-100 dark:from-[#2a2a2a] dark:to-[#333333] rounded-lg px-8 py-4 min-w-32 text-center border border-gray-200 dark:border-white/15">
                      <p className="serif-font text-4xl font-light text-gray-900 dark:text-white">
                        {formData.numGuests}
                      </p>
                      <p className="serif-font text-xs text-gray-600 dark:text-gray-400 mt-1">
                        {formData.numGuests === 0 ? "Apenas você" : formData.numGuests === 1 ? "Pessoa" : "Pessoas"}
                      </p>
                    </div>

                    <button
                      type="button"
                      onClick={incrementGuests}
                      disabled={formData.numGuests >= 8}
                      className="flex items-center justify-center w-12 h-12 rounded-full border-2 border-gray-300 dark:border-white/30 hover:border-gray-900 dark:hover:border-white hover:bg-gray-50 dark:hover:bg-white/10 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <Plus className="w-5 h-5 text-gray-700 dark:text-white" />
                    </button>
                  </div>
                </div>

                {/* Nomes dos Acompanhantes */}
                {formData.numGuests > 0 && (
                  <div className="bg-gray-50 dark:bg-[#2a2a2a] p-4 rounded-md space-y-3">
                    <p className="serif-font text-sm font-medium text-gray-700 dark:text-white">
                      Nomes dos acompanhantes *
                    </p>
                    {formData.guestNames.map((name, index) => (
                      <Input
                        key={index}
                        type="text"
                        name={`guestName_${index}`}
                        value={name}
                        onChange={handleChange}
                        placeholder={`Nome do acompanhante ${index + 1}`}
                        className="w-full dark:bg-[#333333] dark:text-white dark:border-white/15"
                        required
                      />
                    ))}
                  </div>
                )}
              </>
            )}

            {/* Submit Button */}
            <Button
              type="submit"
              disabled={createRSVP.isPending}
              className="w-full serif-font bg-gray-900 dark:bg-white hover:bg-gray-800 dark:hover:bg-gray-200 text-white dark:text-black py-2 rounded-md font-medium transition-colors"
            >
              {createRSVP.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Confirmando presença...
                </>
              ) : (
                "Confirmar Presença"
              )}
            </Button>
          </form>
          
          <div className="mt-12 text-center">
            <p className="serif-font text-lg text-gray-700 dark:text-white">
              Deus abençoe!
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
