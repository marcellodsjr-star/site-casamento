import { motion } from "framer-motion";

export default function VerseSection() {
  return (
    <section className="py-20 px-4 border-b border-gray-200 bg-white">
      <div className="max-w-2xl mx-auto">
        <motion.div
          initial={{ opacity: 0, translateY: 30 }}
          whileInView={{ opacity: 1, translateY: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true, margin: "-100px" }}
          className="border-l-4 border-gray-900 pl-8"
        >
          <p className="serif-font text-xs uppercase tracking-widest text-gray-500 mb-4">
            Isaías 41:20
          </p>
          <p className="serif-font text-xl md:text-2xl italic leading-relaxed text-gray-700">
            "Para que todos vejam, e saibam, e considerem, e juntamente entendam que a mão do Senhor fez isso, e o Santo de Israel o criou."
          </p>
        </motion.div>
      </div>
    </section>
  );
}
