import { useState, useEffect } from "react";
import { motion } from "framer-motion";

const WEDDING_DATE = new Date("2026-12-20T13:00:00").getTime();

export default function HeroSection() {
  const [countdown, setCountdown] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
  });

  useEffect(() => {
    const updateCountdown = () => {
      const now = new Date().getTime();
      const distance = WEDDING_DATE - now;

      if (distance > 0) {
        const totalSeconds = Math.floor(distance / 1000);
        setCountdown({
          days: Math.floor(totalSeconds / (60 * 60 * 24)),
          hours: Math.floor((totalSeconds % (60 * 60 * 24)) / (60 * 60)),
          minutes: Math.floor((totalSeconds % (60 * 60)) / 60),
          seconds: Math.floor(totalSeconds % 60),
        });
      }
    };

    updateCountdown();
    const interval = setInterval(updateCountdown, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <section
      id="hero"
      className="section-hero min-h-screen pt-20 pb-16 flex flex-col items-center justify-center text-center px-4 bg-white dark:bg-[#151515]"
    >
      {/* Monograma */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.8, delay: 0.1 }}
        className="mb-8"
      >
        <img
          src="/monograma.png"
          alt="Monograma T&M"
          className="w-32 h-32 sm:w-40 sm:h-40 object-contain dark:hidden"
        />
        <img
          src="/monograma-dark.png"
          alt="Monograma T&M"
          className="w-32 h-32 sm:w-40 sm:h-40 object-contain hidden dark:block"
        />
      </motion.div>

      {/* Nomes */}
      <motion.h1
        initial={{ opacity: 0, translateY: 30 }}
        animate={{ opacity: 1, translateY: 0 }}
        transition={{ duration: 0.8, delay: 0.3 }}
        className="dancing-script-font text-5xl sm:text-6xl md:text-7xl mb-6 text-gray-900 dark:text-white leading-tight font-normal"
      >
        Thalita e Marcelo
      </motion.h1>

      {/* Data */}
      <motion.p
        initial={{ opacity: 0, translateY: 20 }}
        animate={{ opacity: 1, translateY: 0 }}
        transition={{ duration: 0.8, delay: 0.5 }}
        className="serif-font text-lg sm:text-lg md:text-xl tracking-widest text-gray-600 dark:text-white mb-12"
      >
        20 de dezembro de 2026
      </motion.p>

      {/* Countdown */}
      <motion.div
        initial={{ opacity: 0, translateY: 20 }}
        animate={{ opacity: 1, translateY: 0 }}
        transition={{ duration: 0.8, delay: 0.7 }}
        className="flex gap-1 sm:gap-4 md:gap-12 justify-center flex-wrap"
      >
        <div className="flex flex-col items-center">
          <div className="text-3xl sm:text-3xl md:text-5xl font-serif font-normal text-gray-900 dark:text-white">
            {countdown.days}
          </div>
          <div className="text-xs uppercase tracking-widest text-gray-500 dark:text-gray-400 mt-1 sm:mt-2">
            Dias
          </div>
        </div>
        <div className="text-2xl sm:text-2xl md:text-3xl text-gray-300 dark:text-gray-600">·</div>
        <div className="flex flex-col items-center">
          <div className="text-3xl sm:text-3xl md:text-5xl font-serif font-normal text-gray-900 dark:text-white">
            {countdown.hours}
          </div>
          <div className="text-xs uppercase tracking-widest text-gray-500 dark:text-gray-400 mt-1 sm:mt-2">
            Horas
          </div>
        </div>
        <div className="text-2xl sm:text-2xl md:text-3xl text-gray-300 dark:text-gray-600">·</div>
        <div className="flex flex-col items-center">
          <div className="text-3xl sm:text-3xl md:text-5xl font-serif font-normal text-gray-900 dark:text-white">
            {countdown.minutes}
          </div>
          <div className="text-xs uppercase tracking-widest text-gray-500 dark:text-gray-400 mt-1 sm:mt-2">
            Min
          </div>
        </div>
        <div className="text-2xl sm:text-2xl md:text-3xl text-gray-300 dark:text-gray-600">·</div>
        <div className="flex flex-col items-center">
          <div className="text-3xl sm:text-3xl md:text-5xl font-serif font-normal text-gray-900 dark:text-white">
            {countdown.seconds}
          </div>
          <div className="text-xs uppercase tracking-widest text-gray-500 dark:text-gray-400 mt-1 sm:mt-2">
            Seg
          </div>
        </div>
      </motion.div>
    </section>
  );
}
