import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import * as XLSX from "xlsx";

interface NoivosDashboardProps {
  onLogout: () => void;
}

export default function NoivosDashboard({ onLogout }: NoivosDashboardProps) {
  const [activeTab, setActiveTab] = useState<"confirmacoes" | "recados">("confirmacoes");

  const { data: rsvps = [] } = trpc.rsvp.getAll.useQuery();
  const { data: messages = [] } = trpc.messages.getAll.useQuery();

  const confirmados = rsvps.filter((r: any) => r.willAttend === 1).length;
  const naoConfirmados = rsvps.filter((r: any) => r.willAttend === 0).length;

  const chartData = [
    { name: "Confirmados", value: confirmados, fill: "#3b82f6" },
    { name: "Não Confirmados", value: naoConfirmados, fill: "#ef4444" },
  ];

  const exportToExcel = () => {
    const worksheet = XLSX.utils.json_to_sheet(rsvps.map((r) => ({
      Nome: r.guestName,
      WhatsApp: r.whatsapp,
      "Vai Confirmar": r.willAttend === 1 ? "Sim" : "Não",
      "Número de Acompanhantes": r.numGuests,
      "Nomes dos Acompanhantes": r.guestNames || "-",
    })));

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Confirmações");
    XLSX.writeFile(workbook, "confirmacoes_presenca.xlsx");
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 overflow-y-auto"
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="bg-white dark:bg-[#151515] rounded-lg w-full max-w-4xl m-4 shadow-xl"
      >
        <div className="p-8">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-4">
              <img src="/monograma.png" alt="T&M" className="w-12 h-12 dark:hidden" />
              <img src="/monograma-dark.png" alt="T&M" className="w-12 h-12 hidden dark:block" />
              <h1 className="serif-font text-3xl text-gray-900 dark:text-white">
                {activeTab === "confirmacoes" ? "Confirmações de Presença" : "Recados"}
              </h1>
            </div>
            <Button onClick={onLogout} variant="outline" className="dark:border-white dark:text-white">
              Sair
            </Button>
          </div>

          {/* Tabs */}
          <div className="flex gap-4 mb-8 border-b border-gray-300 dark:border-white">
            <button
              onClick={() => setActiveTab("confirmacoes")}
              className={`pb-4 px-4 font-semibold transition ${
                activeTab === "confirmacoes"
                  ? "text-blue-500 border-b-2 border-blue-500"
                  : "text-gray-600 dark:text-gray-400"
              }`}
            >
              Confirmações
            </button>
            <button
              onClick={() => setActiveTab("recados")}
              className={`pb-4 px-4 font-semibold transition ${
                activeTab === "recados"
                  ? "text-blue-500 border-b-2 border-blue-500"
                  : "text-gray-600 dark:text-gray-400"
              }`}
            >
              Recados
            </button>
          </div>

          {/* Confirmações Tab */}
          {activeTab === "confirmacoes" && (
            <div className="space-y-8">
              {/* Export Button */}
              <Button onClick={exportToExcel} className="mb-4">
                Exportar para Excel
              </Button>

              {/* Tabela */}
              <div className="overflow-x-auto border border-gray-300 dark:border-white rounded-lg">
                <table className="w-full text-sm">
                  <thead className="bg-gray-100 dark:bg-gray-900">
                    <tr>
                      <th className="px-4 py-3 text-left text-gray-900 dark:text-white">Nome</th>
                      <th className="px-4 py-3 text-left text-gray-900 dark:text-white">WhatsApp</th>
                      <th className="px-4 py-3 text-left text-gray-900 dark:text-white">Confirmação</th>
                      <th className="px-4 py-3 text-left text-gray-900 dark:text-white">Acompanhantes</th>
                      <th className="px-4 py-3 text-left text-gray-900 dark:text-white">Nomes</th>
                    </tr>
                  </thead>
                  <tbody>
                    {rsvps.map((rsvp: any, idx: number) => (
                      <tr key={idx} className="border-t border-gray-300 dark:border-white">
                        <td className="px-4 py-3 text-gray-900 dark:text-white">{rsvp.guestName}</td>
                        <td className="px-4 py-3 text-gray-900 dark:text-white">{rsvp.whatsapp}</td>
                        <td className="px-4 py-3">
                          <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                            rsvp.willAttend === 1
                              ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100"
                              : "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-100"
                          }`}>
                            {rsvp.willAttend === 1 ? "Sim" : "Não"}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-gray-900 dark:text-white">{rsvp.numGuests}</td>
                        <td className="px-4 py-3 text-gray-900 dark:text-white">{rsvp.guestNames || "-"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Gráfico */}
              <div className="mt-8">
                <h3 className="serif-font text-xl mb-4 text-gray-900 dark:text-white">Resumo de Confirmações</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={chartData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, value }) => `${name}: ${value}`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {chartData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.fill} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}

          {/* Recados Tab */}
          {activeTab === "recados" && (
            <div className="overflow-x-auto border border-gray-300 dark:border-white rounded-lg">
              <table className="w-full text-sm">
                <thead className="bg-gray-100 dark:bg-gray-900">
                  <tr>
                    <th className="px-4 py-3 text-left text-gray-900 dark:text-white">Nome</th>
                    <th className="px-4 py-3 text-left text-gray-900 dark:text-white">WhatsApp</th>
                    <th className="px-4 py-3 text-left text-gray-900 dark:text-white">Recado</th>
                    <th className="px-4 py-3 text-left text-gray-900 dark:text-white">Público</th>
                  </tr>
                </thead>
                <tbody>
                  {messages.map((msg: any, idx: number) => (
                    <tr key={idx} className="border-t border-gray-300 dark:border-white">
                      <td className="px-4 py-3 text-gray-900 dark:text-white">{msg.guestName}</td>
                      <td className="px-4 py-3 text-gray-900 dark:text-white">{msg.whatsapp}</td>
                      <td className="px-4 py-3 text-gray-900 dark:text-white">{msg.content}</td>
                      <td className="px-4 py-3">
                        <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                          msg.isPublic === 1
                            ? "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100"
                            : "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-100"
                        }`}>
                          {msg.isPublic === 1 ? "Sim" : "Não"}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </motion.div>
    </motion.div>
  );
}
