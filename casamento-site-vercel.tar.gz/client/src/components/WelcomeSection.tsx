import { motion } from "framer-motion";

export default function WelcomeSection() {
  return (
    <section className="section-welcome py-16 px-4 border-b border-gray-200 dark:border-white/15 bg-white dark:bg-[#151515]">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, translateY: 30 }}
          whileInView={{ opacity: 1, translateY: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true, margin: "-100px" }}
          className="text-center space-y-6"
        >
          <p className="serif-font text-lg md:text-xl text-gray-900 dark:text-white">
            A paz de Deus!
          </p>
          
          <p className="serif-font text-lg md:text-xl text-gray-700 dark:text-white leading-relaxed">
            Segundo a vontade de Deus, criamos esse site para compartilhar com vocês os detalhes da organização do nosso casamento. Estamos muito felizes e contamos com a presença de todos no nosso grande dia!
          </p>

          <p className="serif-font text-lg text-gray-700 dark:text-white leading-relaxed">
            Aqui compartilhamos as informações essenciais para o nosso dia, como sugestões de presentes e confirmação de presença.
          </p>

          <p className="serif-font text-lg md:text-xl text-gray-900 dark:text-white mt-8">
            Deus abençoe!
          </p>
        </motion.div>
      </div>
    </section>
  );
}
