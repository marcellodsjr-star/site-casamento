import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Plus, Trash2, Edit2 } from "lucide-react";
import { useState } from "react";

export default function AttendantsList() {
  const { data: attendants = [], isLoading, refetch } = trpc.weddingPlanning.attendants.getAll.useQuery();
  const [editingId, setEditingId] = useState<number | null>(null);

  const deleteAttendant = trpc.weddingPlanning.attendants.delete.useMutation({
    onSuccess: () => refetch(),
  });

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
          Padrinhos e Madrinhas ({attendants.length})
        </h2>
        <Button className="bg-blue-600 hover:bg-blue-700 text-white">
          <Plus className="w-4 h-4 mr-2" />
          Adicionar
        </Button>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full border-collapse">
          <thead>
            <tr className="bg-gray-100 dark:bg-slate-700 border-b-2 border-gray-300 dark:border-slate-600">
              <th className="px-4 py-3 text-left font-semibold text-gray-700 dark:text-gray-200">Nome</th>
              <th className="px-4 py-3 text-left font-semibold text-gray-700 dark:text-gray-200">Função</th>
              <th className="px-4 py-3 text-left font-semibold text-gray-700 dark:text-gray-200">Lado</th>
              <th className="px-4 py-3 text-left font-semibold text-gray-700 dark:text-gray-200">Telefone</th>
              <th className="px-4 py-3 text-center font-semibold text-gray-700 dark:text-gray-200">Ações</th>
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              <tr>
                <td colSpan={5} className="px-4 py-8 text-center text-gray-500">Carregando...</td>
              </tr>
            ) : attendants.length === 0 ? (
              <tr>
                <td colSpan={5} className="px-4 py-8 text-center text-gray-500">Nenhum padrinho/madrinha adicionado</td>
              </tr>
            ) : (
              attendants.map((att) => (
                <tr key={att.id} className="border-b border-gray-200 dark:border-slate-700 hover:bg-gray-50 dark:hover:bg-slate-700/50">
                  <td className="px-4 py-3 text-gray-900 dark:text-white font-medium">{att.name}</td>
                  <td className="px-4 py-3 text-gray-600 dark:text-gray-300">{att.role || "-"}</td>
                  <td className="px-4 py-3 text-gray-600 dark:text-gray-300">{att.side || "-"}</td>
                  <td className="px-4 py-3 text-gray-600 dark:text-gray-300">{att.phone || "-"}</td>
                  <td className="px-4 py-3 flex justify-center gap-2">
                    <button className="p-2 text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg">
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button onClick={() => deleteAttendant.mutate({ id: att.id })} className="p-2 text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
