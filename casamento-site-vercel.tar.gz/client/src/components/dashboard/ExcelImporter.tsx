import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { AlertCircle, CheckCircle, Upload, Loader } from 'lucide-react';

interface ImportStats {
  guestsImported: number;
  attendantsImported: number;
  vendorsImported: number;
  giftsImported: number;
  eventsImported: number;
  expensesImported: number;
  errors: string[];
}

export function ExcelImporter() {
  const [file, setFile] = useState<File | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<{ success: boolean; stats: ImportStats; message: string } | null>(null);
  const [isDragging, setIsDragging] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      setFile(selectedFile);
      setResult(null);
    }
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    const droppedFile = e.dataTransfer.files?.[0];
    if (droppedFile && (droppedFile.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || droppedFile.type === 'application/vnd.ms-excel')) {
      setFile(droppedFile);
      setResult(null);
    }
  };

  const handleImport = async () => {
    if (!file) return;

    setIsLoading(true);
    try {
      const formData = new FormData();
      formData.append('file', file);

      const response = await fetch('/api/import-excel', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        throw new Error('Erro ao importar arquivo');
      }

      const result = await response.json();
      setResult(result);
    } catch (error) {
      setResult({
        success: false,
        stats: {
          guestsImported: 0,
          attendantsImported: 0,
          vendorsImported: 0,
          giftsImported: 0,
          eventsImported: 0,
          expensesImported: 0,
          errors: [String(error)],
        },
        message: 'Erro ao importar arquivo',
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="p-6">
        <h3 className="text-lg font-semibold mb-4">Importar Dados do Excel</h3>

        {/* Upload Area */}
        <div
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
            isDragging
              ? 'border-blue-500 bg-blue-50 dark:bg-blue-950'
              : 'border-gray-300 dark:border-gray-600'
          }`}
        >
          <Upload className="w-12 h-12 mx-auto mb-4 text-gray-400" />
          <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
            Arraste seu arquivo Excel aqui ou clique para selecionar
          </p>
          <input
            type="file"
            accept=".xlsx,.xls"
            onChange={handleFileChange}
            className="hidden"
            id="excel-upload"
          />
          <label htmlFor="excel-upload">
            <Button variant="outline" asChild className="cursor-pointer">
              <span>Selecionar Arquivo</span>
            </Button>
          </label>
        </div>

        {/* Selected File */}
        {file && (
          <div className="mt-4 p-4 bg-blue-50 dark:bg-blue-950 rounded-lg">
            <p className="text-sm font-medium text-blue-900 dark:text-blue-100">
              Arquivo selecionado: <span className="font-bold">{file.name}</span>
            </p>
            <p className="text-xs text-blue-700 dark:text-blue-300 mt-1">
              Tamanho: {(file.size / 1024).toFixed(2)} KB
            </p>
          </div>
        )}

        {/* Import Button */}
        <div className="mt-6 flex gap-3">
          <Button
            onClick={handleImport}
            disabled={!file || isLoading}
            className="flex-1"
          >
            {isLoading ? (
              <>
                <Loader className="w-4 h-4 mr-2 animate-spin" />
                Importando...
              </>
            ) : (
              'Importar Dados'
            )}
          </Button>
          {file && (
            <Button
              variant="outline"
              onClick={() => {
                setFile(null);
                setResult(null);
              }}
            >
              Limpar
            </Button>
          )}
        </div>
      </Card>

      {/* Results */}
      {result && (
        <Card className={`p-6 ${result.success ? 'border-green-200 dark:border-green-800' : 'border-red-200 dark:border-red-800'}`}>
          <div className="flex items-start gap-4">
            {result.success ? (
              <CheckCircle className="w-6 h-6 text-green-600 dark:text-green-400 flex-shrink-0 mt-1" />
            ) : (
              <AlertCircle className="w-6 h-6 text-red-600 dark:text-red-400 flex-shrink-0 mt-1" />
            )}
            <div className="flex-1">
              <h4 className={`font-semibold ${result.success ? 'text-green-900 dark:text-green-100' : 'text-red-900 dark:text-red-100'}`}>
                {result.message}
              </h4>

              {result.success && (
                <div className="mt-4 grid grid-cols-2 md:grid-cols-3 gap-4">
                  {result.stats.guestsImported > 0 && (
                    <div className="text-sm">
                      <p className="text-gray-600 dark:text-gray-400">Convidados</p>
                      <p className="text-2xl font-bold text-green-600 dark:text-green-400">
                        {result.stats.guestsImported}
                      </p>
                    </div>
                  )}
                  {result.stats.attendantsImported > 0 && (
                    <div className="text-sm">
                      <p className="text-gray-600 dark:text-gray-400">Padrinhos</p>
                      <p className="text-2xl font-bold text-green-600 dark:text-green-400">
                        {result.stats.attendantsImported}
                      </p>
                    </div>
                  )}
                  {result.stats.vendorsImported > 0 && (
                    <div className="text-sm">
                      <p className="text-gray-600 dark:text-gray-400">Fornecedores</p>
                      <p className="text-2xl font-bold text-green-600 dark:text-green-400">
                        {result.stats.vendorsImported}
                      </p>
                    </div>
                  )}
                  {result.stats.giftsImported > 0 && (
                    <div className="text-sm">
                      <p className="text-gray-600 dark:text-gray-400">Presentes</p>
                      <p className="text-2xl font-bold text-green-600 dark:text-green-400">
                        {result.stats.giftsImported}
                      </p>
                    </div>
                  )}
                  {result.stats.eventsImported > 0 && (
                    <div className="text-sm">
                      <p className="text-gray-600 dark:text-gray-400">Eventos</p>
                      <p className="text-2xl font-bold text-green-600 dark:text-green-400">
                        {result.stats.eventsImported}
                      </p>
                    </div>
                  )}
                  {result.stats.expensesImported > 0 && (
                    <div className="text-sm">
                      <p className="text-gray-600 dark:text-gray-400">Despesas</p>
                      <p className="text-2xl font-bold text-green-600 dark:text-green-400">
                        {result.stats.expensesImported}
                      </p>
                    </div>
                  )}
                </div>
              )}

              {result.stats.errors.length > 0 && (
                <div className="mt-4">
                  <p className="text-sm font-medium text-red-900 dark:text-red-100 mb-2">
                    Erros encontrados:
                  </p>
                  <ul className="text-xs text-red-800 dark:text-red-200 space-y-1">
                    {result.stats.errors.slice(0, 5).map((error, idx) => (
                      <li key={idx}>• {error}</li>
                    ))}
                    {result.stats.errors.length > 5 && (
                      <li>... e mais {result.stats.errors.length - 5} erros</li>
                    )}
                  </ul>
                </div>
              )}
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}
