import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Plus, Trash2, Edit2 } from "lucide-react";
import EditGuestModal from "./modals/EditGuestModal";
import AddGuestModal from "./modals/AddGuestModal";

export default function GuestsList() {
  const { data: guests = [], isLoading, refetch } = trpc.weddingPlanning.guests.getAll.useQuery();
  const [editingGuest, setEditingGuest] = useState<any>(null);
  const [showAddModal, setShowAddModal] = useState(false);

  const deleteGuest = trpc.weddingPlanning.guests.delete.useMutation({
    onSuccess: () => refetch(),
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
          Lista de Convidados ({guests.length})
        </h2>
        <Button
          onClick={() => setShowAddModal(true)}
          className="bg-blue-600 hover:bg-blue-700 text-white"
        >
          <Plus className="w-4 h-4 mr-2" />
          Adicionar Convidado
        </Button>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full border-collapse">
          <thead>
            <tr className="bg-gray-100 dark:bg-slate-700 border-b-2 border-gray-300 dark:border-slate-600">
              <th className="px-4 py-3 text-left font-semibold text-gray-700 dark:text-gray-200">Nome</th>
              <th className="px-4 py-3 text-left font-semibold text-gray-700 dark:text-gray-200">Lado</th>
              <th className="px-4 py-3 text-left font-semibold text-gray-700 dark:text-gray-200">Status</th>
              <th className="px-4 py-3 text-left font-semibold text-gray-700 dark:text-gray-200">Acompanhantes</th>
              <th className="px-4 py-3 text-left font-semibold text-gray-700 dark:text-gray-200">Telefone</th>
              <th className="px-4 py-3 text-center font-semibold text-gray-700 dark:text-gray-200">Ações</th>
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              <tr>
                <td colSpan={6} className="px-4 py-8 text-center text-gray-500">
                  Carregando...
                </td>
              </tr>
            ) : guests.length === 0 ? (
              <tr>
                <td colSpan={6} className="px-4 py-8 text-center text-gray-500">
                  Nenhum convidado adicionado ainda
                </td>
              </tr>
            ) : (
              guests.map((guest) => (
                <tr
                  key={guest.id}
                  className={`border-b border-gray-200 dark:border-slate-700 hover:bg-gray-50 dark:hover:bg-slate-700/50 transition-colors ${
                    guest.isPending === 1 ? "bg-yellow-50 dark:bg-yellow-900/20" : ""
                  }`}
                >
                  <td className="px-4 py-3 text-gray-900 dark:text-white font-medium">{guest.name}</td>
                  <td className="px-4 py-3 text-gray-600 dark:text-gray-300">{guest.side || "-"}</td>
                  <td className="px-4 py-3">
                    <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                      guest.status === "confirmado"
                        ? "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-200"
                        : guest.status === "recusado"
                        ? "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-200"
                        : "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-200"
                    }`}>
                      {guest.status || "pendente"}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-gray-600 dark:text-gray-300">{guest.numGuests || 1}</td>
                  <td className="px-4 py-3 text-gray-600 dark:text-gray-300">{guest.phone || "-"}</td>
                  <td className="px-4 py-3 flex justify-center gap-2">
                    <button
                      onClick={() => setEditingGuest(guest)}
                      className="p-2 text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg transition-colors"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => deleteGuest.mutate({ id: guest.id })}
                      className="p-2 text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Modals */}
      {editingGuest && (
        <EditGuestModal
          guest={editingGuest}
          onClose={() => setEditingGuest(null)}
          onSuccess={() => {
            setEditingGuest(null);
            refetch();
          }}
        />
      )}
      {showAddModal && (
        <AddGuestModal
          onClose={() => setShowAddModal(false)}
          onSuccess={() => {
            setShowAddModal(false);
            refetch();
          }}
        />
      )}
    </div>
  );
}
