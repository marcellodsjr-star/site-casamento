import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Plus, Trash2, Edit2 } from "lucide-react";

export default function GiftsList() {
  const { data: gifts = [], isLoading, refetch } = trpc.weddingPlanning.gifts.getAll.useQuery();
  const deleteGift = trpc.weddingPlanning.gifts.delete.useMutation({ onSuccess: () => refetch() });

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Presentes ({gifts.length})</h2>
        <Button className="bg-blue-600 hover:bg-blue-700 text-white"><Plus className="w-4 h-4 mr-2" />Adicionar</Button>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full border-collapse">
          <thead>
            <tr className="bg-gray-100 dark:bg-slate-700 border-b-2 border-gray-300 dark:border-slate-600">
              <th className="px-4 py-3 text-left font-semibold">Nome</th>
              <th className="px-4 py-3 text-left font-semibold">Categoria</th>
              <th className="px-4 py-3 text-left font-semibold">Valor</th>
              <th className="px-4 py-3 text-left font-semibold">Status</th>
              <th className="px-4 py-3 text-center font-semibold">Ações</th>
            </tr>
          </thead>
          <tbody>
            {gifts.length === 0 ? (
              <tr><td colSpan={5} className="px-4 py-8 text-center text-gray-500">Nenhum presente adicionado</td></tr>
            ) : (
              gifts.map((g) => (
                <tr key={g.id} className="border-b border-gray-200 dark:border-slate-700 hover:bg-gray-50 dark:hover:bg-slate-700/50">
                  <td className="px-4 py-3 font-medium">{g.name}</td>
                  <td className="px-4 py-3">{g.category || "-"}</td>
                  <td className="px-4 py-3">{g.value || "-"}</td>
                  <td className="px-4 py-3"><span className="px-2 py-1 rounded text-sm bg-blue-100 dark:bg-blue-900/30">{g.status}</span></td>
                  <td className="px-4 py-3 flex justify-center gap-2">
                    <button className="p-2 text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg"><Edit2 className="w-4 h-4" /></button>
                    <button onClick={() => deleteGift.mutate({ id: g.id })} className="p-2 text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg"><Trash2 className="w-4 h-4" /></button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
