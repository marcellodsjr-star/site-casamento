import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import NoivosLogin from "./NoivosLogin";
import NoivosDashboard from "./NoivosDashboard";
import { isAuthenticated, clearSession } from "@/lib/auth";

export default function Footer() {
  const [showLogin, setShowLogin] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(isAuthenticated());

  const handleMonogramClick = () => {
    if (isLoggedIn) {
      setIsLoggedIn(false);
      clearSession();
    } else {
      setShowLogin(true);
    }
  };

  const handleLoginSuccess = () => {
    setShowLogin(false);
    setIsLoggedIn(true);
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    clearSession();
  };

  return (
    <footer className="section-footer text-gray-900 dark:text-white py-16 px-4 border-t border-gray-200 dark:border-white/15 bg-white dark:bg-[#151515]">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, translateY: 30 }}
          whileInView={{ opacity: 1, translateY: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true, margin: "-100px" }}
          className="text-center"
        >
          {/* Monograma - Botão Secreto */}
          <div className="mb-8">
            <button
              onClick={handleMonogramClick}
              className="cursor-pointer hover:opacity-80 transition-opacity"
              title="Área dos Noivos"
            >
              <img
                src="/monograma.png"
                alt="T&M"
                className="w-24 h-24 object-contain mx-auto opacity-100 dark:hidden"
              />
              <img
                src="/monograma-dark.png"
                alt="T&M"
                className="w-24 h-24 object-contain mx-auto opacity-100 hidden dark:block"
              />
            </button>
          </div>

          {/* Nomes */}
          <p className="dancing-script-font text-4xl mb-4 text-gray-900 dark:text-white">
            Thalita e Marcelo
          </p>

          {/* Data */}
          <p className="serif-font text-lg text-gray-600 dark:text-gray-300 mb-8">
            20 de dezembro de 2026
          </p>

          {/* Divider */}
          <div className="w-16 h-px bg-gray-300 dark:bg-white/30 mx-auto mb-8"></div>

          {/* Mensagem */}
          <p className="serif-font text-gray-700 dark:text-gray-200 max-w-md mx-auto mb-4">
            "Para que todos vejam, e saibam, e considerem, e juntamente entendam que a mão do Senhor fez isso, e o Santo de Israel o criou."
          </p>
          <p className="serif-font text-sm text-gray-600 dark:text-gray-400">
            Isaías 41:20
          </p>

          {/* Copyright */}
          <div className="mt-12 pt-8 border-t border-gray-200 dark:border-white/15">
            <p className="serif-font text-sm text-gray-600 dark:text-gray-400">
              © 2026 Casamento Thalita & Marcelo. Todos os direitos reservados.
            </p>
          </div>
        </motion.div>
      </div>

      {/* Modais */}
      <AnimatePresence>
        {showLogin && (
          <NoivosLogin
            onLoginSuccess={handleLoginSuccess}
            onClose={() => setShowLogin(false)}
          />
        )}
        {isLoggedIn && (
          <NoivosDashboard onLogout={handleLogout} />
        )}
      </AnimatePresence>
    </footer>
  );
}
