import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import WelcomeSection from "@/components/WelcomeSection";
import LocationSection from "@/components/LocationSection";
import GiftsSection from "@/components/GiftsSection";
import RSVPSection from "@/components/RSVPSection";
import MessagesSection from "@/components/MessagesSection";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Navbar />
      <main className="flex-1 pt-16">
        <HeroSection />
        <WelcomeSection />
        <LocationSection />
        <GiftsSection />
        <RSVPSection />
        <MessagesSection />
      </main>
      <Footer />
    </div>
  );
}
