const ADMIN_EMAIL = "marcellodsjr@gmail.com";
const ADMIN_PASSWORD = "Thalita@142399";
const SESSION_KEY = "noivos_session";

export const validateLogin = (email: string, password: string): boolean => {
  return email === ADMIN_EMAIL && password === ADMIN_PASSWORD;
};

export const setSession = (token: string): void => {
  localStorage.setItem(SESSION_KEY, token);
};

export const getSession = (): string | null => {
  return localStorage.getItem(SESSION_KEY);
};

export const clearSession = (): void => {
  localStorage.removeItem(SESSION_KEY);
};

export const isAuthenticated = (): boolean => {
  return !!getSession();
};
