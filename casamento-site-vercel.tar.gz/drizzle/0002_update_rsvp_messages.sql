ALTER TABLE `rsvps` RENAME COLUMN `message` TO `whatsapp`;--> statement-breakpoint
ALTER TABLE `messages` MODIFY COLUMN `isPublic` int NOT NULL DEFAULT 0;--> statement-breakpoint
ALTER TABLE `rsvps` MODIFY COLUMN `numGuests` int NOT NULL DEFAULT 0;--> statement-breakpoint
ALTER TABLE `rsvps` MODIFY COLUMN `whatsapp` varchar(20) NOT NULL;--> statement-breakpoint
ALTER TABLE `messages` ADD `whatsapp` varchar(20) NOT NULL;--> statement-breakpoint
ALTER TABLE `rsvps` ADD `willAttend` int NOT NULL;--> statement-breakpoint
ALTER TABLE `rsvps` ADD `guestNames` text;