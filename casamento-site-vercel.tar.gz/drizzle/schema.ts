import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * RSVP table for wedding confirmations
 */
export const rsvps = mysqlTable("rsvps", {
  id: int("id").autoincrement().primaryKey(),
  guestName: varchar("guestName", { length: 255 }).notNull(),
  whatsapp: varchar("whatsapp", { length: 20 }).notNull(),
  willAttend: int("willAttend").notNull(), // 1 = sim, 0 = não
  numGuests: int("numGuests").notNull().default(0),
  guestNames: text("guestNames"), // JSON array of guest names
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type RSVP = typeof rsvps.$inferSelect;
export type InsertRSVP = typeof rsvps.$inferInsert;

/**
 * Messages table for guest messages/wishes (private, only visible to couple)
 */
export const messages = mysqlTable("messages", {
  id: int("id").autoincrement().primaryKey(),
  guestName: varchar("guestName", { length: 255 }).notNull(),
  whatsapp: varchar("whatsapp", { length: 20 }).notNull(),
  content: text("content").notNull(),
  isPublic: int("isPublic").default(0).notNull(), // 1 = true, 0 = false (default private)
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Message = typeof messages.$inferSelect;
export type InsertMessage = typeof messages.$inferInsert;

/**
 * Wedding Planning - Guests Table
 */
export const weddingGuests = mysqlTable("wedding_guests", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  side: varchar("side", { length: 50 }), // "noiva", "noivo", "ambos"
  status: varchar("status", { length: 50 }).default("pendente"), // "confirmado", "pendente", "recusado"
  isPending: int("isPending").default(0), // 1 = amarelo (talvez chamar), 0 = normal
  numGuests: int("numGuests").default(1),
  phone: varchar("phone", { length: 20 }),
  email: varchar("email", { length: 255 }),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type WeddingGuest = typeof weddingGuests.$inferSelect;
export type InsertWeddingGuest = typeof weddingGuests.$inferInsert;

/**
 * Wedding Planning - Groomsmen/Bridesmaids Table
 */
export const weddingAttendants = mysqlTable("wedding_attendants", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  role: varchar("role", { length: 50 }), // "padrinho", "madrinha"
  side: varchar("side", { length: 50 }), // "noiva", "noivo"
  phone: varchar("phone", { length: 20 }),
  email: varchar("email", { length: 255 }),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type WeddingAttendant = typeof weddingAttendants.$inferSelect;
export type InsertWeddingAttendant = typeof weddingAttendants.$inferInsert;

/**
 * Wedding Planning - Vendors Table (Fotógrafo, Banda, etc)
 */
export const weddingVendors = mysqlTable("wedding_vendors", {
  id: int("id").autoincrement().primaryKey(),
  type: varchar("type", { length: 50 }).notNull(), // "fotografo", "banda", "buffet", "decoracao"
  name: varchar("name", { length: 255 }).notNull(),
  phone: varchar("phone", { length: 20 }),
  email: varchar("email", { length: 255 }),
  value: varchar("value", { length: 50 }), // Valor em R$
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type WeddingVendor = typeof weddingVendors.$inferSelect;
export type InsertWeddingVendor = typeof weddingVendors.$inferInsert;

/**
 * Wedding Planning - Gifts Table
 */
export const weddingGifts = mysqlTable("wedding_gifts", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  category: varchar("category", { length: 50 }), // "lista_presentes", "cha_panela"
  description: text("description"),
  value: varchar("value", { length: 50 }), // Valor em R$
  status: varchar("status", { length: 50 }).default("disponivel"), // "disponivel", "reservado", "comprado"
  reservedBy: varchar("reservedBy", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type WeddingGift = typeof weddingGifts.$inferSelect;
export type InsertWeddingGift = typeof weddingGifts.$inferInsert;

/**
 * Wedding Planning - Events/Schedule Table
 */
export const weddingEvents = mysqlTable("wedding_events", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  type: varchar("type", { length: 50 }), // "cerimonia", "coquetel", "recepcao", "cortejo"
  location: varchar("location", { length: 255 }),
  startTime: varchar("startTime", { length: 50 }),
  endTime: varchar("endTime", { length: 50 }),
  description: text("description"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type WeddingEvent = typeof weddingEvents.$inferSelect;
export type InsertWeddingEvent = typeof weddingEvents.$inferInsert;

/**
 * Wedding Planning - Budget/Expenses Table
 */
export const weddingExpenses = mysqlTable("wedding_expenses", {
  id: int("id").autoincrement().primaryKey(),
  category: varchar("category", { length: 100 }).notNull(),
  description: text("description"),
  value: varchar("value", { length: 50 }).notNull(),
  status: varchar("status", { length: 50 }).default("planejado"), // "planejado", "pago"
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type WeddingExpense = typeof weddingExpenses.$inferSelect;
export type InsertWeddingExpense = typeof weddingExpenses.$inferInsert;

/**
 * Wedding Planning - General Info Table
 */
export const weddingInfo = mysqlTable("wedding_info", {
  id: int("id").autoincrement().primaryKey(),
  brideFullName: varchar("brideFullName", { length: 255 }),
  groomFullName: varchar("groomFullName", { length: 255 }),
  weddingDate: varchar("weddingDate", { length: 50 }),
  weddingLocation: varchar("weddingLocation", { length: 255 }),
  totalBudget: varchar("totalBudget", { length: 50 }),
  totalGuests: int("totalGuests").default(0),
  totalAttendants: int("totalAttendants").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type WeddingInfo = typeof weddingInfo.$inferSelect;
export type InsertWeddingInfo = typeof weddingInfo.$inferInsert;
