CREATE TABLE `wedding_attendants` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`role` varchar(50),
	`side` varchar(50),
	`phone` varchar(20),
	`email` varchar(255),
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `wedding_attendants_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `wedding_events` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`type` varchar(50),
	`location` varchar(255),
	`startTime` varchar(50),
	`endTime` varchar(50),
	`description` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `wedding_events_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `wedding_expenses` (
	`id` int AUTO_INCREMENT NOT NULL,
	`category` varchar(100) NOT NULL,
	`description` text,
	`value` varchar(50) NOT NULL,
	`status` varchar(50) DEFAULT 'planejado',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `wedding_expenses_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `wedding_gifts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`category` varchar(50),
	`description` text,
	`value` varchar(50),
	`status` varchar(50) DEFAULT 'disponivel',
	`reservedBy` varchar(255),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `wedding_gifts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `wedding_guests` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`side` varchar(50),
	`status` varchar(50) DEFAULT 'pendente',
	`isPending` int DEFAULT 0,
	`numGuests` int DEFAULT 1,
	`phone` varchar(20),
	`email` varchar(255),
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `wedding_guests_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `wedding_info` (
	`id` int AUTO_INCREMENT NOT NULL,
	`brideFullName` varchar(255),
	`groomFullName` varchar(255),
	`weddingDate` varchar(50),
	`weddingLocation` varchar(255),
	`totalBudget` varchar(50),
	`totalGuests` int DEFAULT 0,
	`totalAttendants` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `wedding_info_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `wedding_vendors` (
	`id` int AUTO_INCREMENT NOT NULL,
	`type` varchar(50) NOT NULL,
	`name` varchar(255) NOT NULL,
	`phone` varchar(20),
	`email` varchar(255),
	`value` varchar(50),
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `wedding_vendors_id` PRIMARY KEY(`id`)
);
